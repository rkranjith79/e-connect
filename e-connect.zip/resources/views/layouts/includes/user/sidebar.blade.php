<div class="mobile-sidebar" data-color="purple" data-background-color="white">
    <div class="logo">
        <a href="index.html" class="simple-text logo-mini">
            <div class="logo-img">
                <img src="uploads/all/aCHiR7dvkLDlSIOXSMzt82R8AnhvO7jrlWGDB1sL.png"
                    alt="Kalyana Medai Matrimony" class="mw-100 h-auto">
            </div>
        </a>
    </div>
    <div class="mobile-sidebar-wrapper">
        <ul class="nav">
            <li class="nav-item  active">
                <a class="nav-link" href="index.html">
                    <i class="fa fa-home"></i>
                    <p class="mobile-sidebar-normal"> Home </p>
                </a>
            </li>

            <li class="nav-item  ">
                <a class="nav-link" href="users/login.html">
                    <i class="fas fa-users"></i>
                    <p class="mobile-sidebar-normal"> View Profiles </p>
                </a>
            </li>
            <li class="nav-item  ">
                <a class="nav-link" href="users/login.html">
                    <i class="fas fa-search"></i>
                    <p class="mobile-sidebar-normal"> Search </p>
                </a>
            </li>
            <li class="nav-item  ">
                <a class="nav-link" href="packages.html">
                    <i class="fas fa-trophy"></i>
                    <p class="mobile-sidebar-normal"> Premium Plans </p>
                </a>
            </li>
            <li class="nav-item  ">
                <a class="nav-link" href="events.html">
                    <i class="fas fa-ticket-alt"></i>
                    <p class="mobile-sidebar-normal"> Events </p>
                </a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="login.html">
                    <i class="fas fa-sign-in-alt"></i>
                    <p class="mobile-sidebar-normal"> உள் நுழைய </p>
                </a>
            </li>
        </ul>
        <!-- Navigation Bar	end -->
    </div>
</div>
