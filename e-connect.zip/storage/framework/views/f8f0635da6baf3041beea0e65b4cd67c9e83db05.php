<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="mdi mdi-home menu-icon"></i>
                    <span class="menu-title">Users</span>
                </a>
            </li>
        
    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\e-connect\resources\views/layouts/includes/admin/sidebar.blade.php ENDPATH**/ ?>